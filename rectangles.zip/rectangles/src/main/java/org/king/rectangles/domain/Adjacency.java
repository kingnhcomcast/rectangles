package org.king.rectangles.domain;

/**
 * Adjacency types
 */
public enum Adjacency {
    NONE,
    SUBLINE,
    PROPER,
    PARTIAL
}
