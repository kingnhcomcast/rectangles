package org.king.rectangles.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.*;

/**
 * Represents a point with X,Y coordinates.
 */
@Data
@AllArgsConstructor
@Builder
public class Point {
    @Column
    private int x;
    @Column
    private int y;
}
