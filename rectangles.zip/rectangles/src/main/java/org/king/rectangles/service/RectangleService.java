package org.king.rectangles.service;

import org.king.rectangles.exception.NotFoundException;
import org.king.rectangles.domain.Adjacency;
import org.king.rectangles.domain.Rectangle;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service class that manages the collection of rectangles
 */
@Service
public class RectangleService {
    private final Map<String, Rectangle> rectangles = new HashMap<>();

    /**
     * Retrieve the rectangle with the specified id.
     * @param id    id of the rectangel to retrieve
     * @return      the rectangle
     * @throws NotFoundException    if the specified id is not found
     */
    public Rectangle getRectangle(String id) throws NotFoundException {
        Rectangle rectangle = rectangles.get(id);
        if(rectangle == null) {
            throw new NotFoundException();
        }
        return rectangle;
    }

    /**
     * Adds the provided rectange to the collection and generates an id.
     * @param rectangle rectangle to add
     * @return  the added rectangle with id
     */
    public Rectangle addRectangle(Rectangle rectangle) {
        String id = Integer.toString(rectangles.size() + 1);
        rectangle.setId(id);
        rectangles.put(id, rectangle);
        return rectangle;
    }

    /**
     * Returns all rectangles.
     * @return  list of rectangles
     */
    public List<Rectangle> getRectangles() {
        return rectangles.values().stream().toList();
    }

    /**
     * Returns the relationship between 2 rectangles
     * @param id1   id of the first rectangle
     * @param id2   id of the second rectangle
     * @return      a string describing the relationship
     */
    public String getRelationship(String id1, String id2) {
        Rectangle r1 = getRectangle(id1);
        Rectangle r2 = getRectangle(id2);

        if(r1.contains(r2)) {
            return "Contains";
        } else if(r1.getAdjacent(r2) != Adjacency.NONE) {
            return "Adjacent:" + r1.getAdjacent(r2).name();
        } else if(r1.getIntersectingPoints(r2).size() != 0) {
            return r1.getIntersectingPoints(r2).toString();
        } else {
            return "none";
        }
    }
}
