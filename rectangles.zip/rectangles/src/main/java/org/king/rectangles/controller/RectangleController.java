package org.king.rectangles.controller;

import org.king.rectangles.exception.NotFoundException;
import org.king.rectangles.domain.Rectangle;
import org.king.rectangles.service.RectangleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller to provide a REST API for the Rectangle resource
 */
@RestController
public class RectangleController {
    private final RectangleService service;

    @Autowired
    public RectangleController(RectangleService service) {
        this.service = service;
    }

    /**
     * Retrieve all rectangles.
     * @return list of rectangles
     */
    @GetMapping("/rectangles")
    public List<Rectangle> getRectangles() {
        return service.getRectangles();
    }

    /**
     * Retrieve a specific rectangle.
     * @param id    id of the rectangle to retrieve
     * @return      the rectangle
     * @throws NotFoundException if rectangle is not found
     */
    @GetMapping("/rectangles/{id}")
    public Rectangle getRectangle(@PathVariable String id) throws NotFoundException {
        return service.getRectangle(id);
    }

    /**
     * Creates the provided rectangle.
     * @param rectangle the rectangle to create
     * @return          the rectangle with generated id
     */
    @PostMapping("/rectangles")
    public Rectangle postRectangle(@RequestBody Rectangle rectangle) {
        return service.addRectangle(rectangle);
    }

    /**
     * Calculate and return the relationship between 2 rectangles which must already exist.
     *
     * note: this is not really a RESTfull operation on a resource, a SOAP/RPC call may be more appropriate.
     * @param id1   id of the first rectangle
     * @param id2   id of the second rectangle
     * @return      the relationship indicating containment, intersection, or adjacency
     */
    @GetMapping("/rectangles/relationship")
    public String getRectangleRelationship(@RequestParam String id1, @RequestParam String id2) {
        return service.getRelationship(id1, id2);
    }
}
