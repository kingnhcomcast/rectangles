package org.king.rectangles.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a rectangle specified by 2 points.
 */
@Builder
@Data
public class Rectangle {
    /**
     * Uinique ID of this rectangle
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String id;

    /**
     * The upper left point
     */
    private Point ul;
    /**
     * The lower right point
     */
    private Point lr;

    /**
     * Returns the top Y
     * @return Y value of the top line
     */
    @JsonIgnore
    public int getTop() {
        return ul.getY();
    }

    /**
     * Returns the bottom Y
     * @return Y value of the bottom line
     */
    @JsonIgnore
    public int getBottom() {
        return lr.getY();
    }

    /**
     * Returns the left X
     * @return  X value of the left line
     */
    @JsonIgnore
    public int getLeft() {
        return ul.getX();
    }

    /**
     * Returns the right X
     * @return X value of the right line
     */
    @JsonIgnore
    public int getRight() {
        return lr.getX();
    }

    /**
     * Calculates if the specified rectangle intersects this one.
     * @param rectangle rectangle to compare to
     * @return  a list of the intersecting points, empty if there are none
     */
    public List<Point> getIntersectingPoints(Rectangle rectangle) {
        List<Point> points = new ArrayList<>();

        //first check if no intersection
        if(getRight() < rectangle.getLeft() || getLeft() > rectangle.getRight() ||
            getTop() < rectangle.getBottom() || getBottom() > rectangle.getTop()) {
            return points;
        }

        //intersects on bottom
        if(getBottom() < rectangle.getTop() && getBottom() > rectangle.getBottom()) {
            if(rectangle.getLeft() > getLeft() && rectangle.getLeft() < getRight()) {
                points.add(Point.builder().x(rectangle.getLeft()).y(getBottom()).build());
            }
            if(rectangle.getRight() > getLeft() && rectangle.getRight() < getRight()) {
                points.add(Point.builder().x(rectangle.getRight()).y(getBottom()).build());
            }
        }

        //intersects on top
        if(getTop() < rectangle.getTop() && getTop() > rectangle.getBottom()) {
            points.add(Point.builder().x(getRight()).y(rectangle.getTop()).build());
            points.add(Point.builder().x(getLeft()).y(rectangle.getTop()).build());
        }

        //intersects right
        if(getRight() < rectangle.getRight() && getRight() > rectangle.getLeft()) {
            if(rectangle.getTop() < getTop() && rectangle.getTop() > getBottom()) {
                points.add(Point.builder().x(getRight()).y(rectangle.getTop()).build());
            }
            if(rectangle.getBottom() < getTop() && rectangle.getBottom() > getBottom()) {
                points.add(Point.builder().x(getRight()).y(rectangle.getBottom()).build());
            }
        }

        //intersects left
        if(getLeft() > rectangle.getLeft() && getLeft() < rectangle.getRight()) {
            points.add(Point.builder().x(getLeft()).y(rectangle.getTop()).build());
            points.add(Point.builder().x(getLeft()).y(rectangle.getBottom()).build());
        }

        return points;
    }

    /**
     * Calculates if the specified rectangle is contained by this one.
     * @param rectangle rectangle to compare
     * @return  true if rectangle is contained
     */
    public boolean contains(Rectangle rectangle) {
        return (getTop() > rectangle.getTop() && getBottom() < rectangle.getBottom() &&
                getLeft() < rectangle.getLeft() && getRight() > rectangle.getRight());
    }

    /**
     * Calculates the adjacency of the specified rectangle to this rectangle.
     * @param rectangle the rectangle to compare
     * @return Enum specifying the Adjacency relationship
     */
    public Adjacency getAdjacent(Rectangle rectangle) {

        //if the adjacent line is on the top or bottom of the rectangle
        if(getTop() == rectangle.getTop() || getTop() == rectangle.getBottom() || getBottom() == rectangle.getBottom()) {
            if(getLeft() == rectangle.getLeft() && getRight() == rectangle.getRight()) {
                return Adjacency.PROPER;
            }
            if(getLeft() < rectangle.getLeft() && getRight() > rectangle.getRight()) {
                return Adjacency.SUBLINE;
            }
            if ((getLeft() > rectangle.getLeft() && getRight() > rectangle.getRight() && getLeft() < rectangle.getRight())  ||
                    ((getLeft() < rectangle.getLeft() && getRight() < rectangle.getRight() && getRight() > rectangle.getLeft()))) {
                return Adjacency.PARTIAL;
            }
        }  else if(getLeft() == rectangle.getLeft() || getLeft() == rectangle.getRight() ||
                getRight() == rectangle.getRight()) {
            //else if the adjacent line is on the left or right of the rectangle
            if(getTop() == rectangle.getTop() && getBottom() == rectangle.getBottom()) {
                return Adjacency.PROPER;
            }
            if(getTop() > rectangle.getTop() && getBottom() < rectangle.getBottom()) {
                return Adjacency.SUBLINE;
            }
            if((getTop() < rectangle.getTop() && getBottom() < rectangle.getBottom()) ||
                    (getBottom() < rectangle.getBottom() && getTop() < rectangle.getTop())) {
                return Adjacency.PARTIAL;
            }
        }

        return Adjacency.NONE;
    }
}
