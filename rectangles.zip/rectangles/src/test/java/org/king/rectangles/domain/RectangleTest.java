package org.king.rectangles.domain;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

/*
The following are visual diagrams of the rectangles used in these tests.
      r5---------------+
      |                |
      |   r6---+    r7-+---+
      |   |    |    |  |   |
      r1--+----+----+--+---+      r4---+
      |   r2---+    r3-+---+      |    |
      |   |    |    |  |   |      +----+
      |   +----+    +--+---+
      +----------------+

            r10--+
            |    |
      r1----+----+-----+
   r9-+-+   |    |  r3-+---+
   |  | |   +----+  |  |   |
   +--+-+           +--+---+
      |                |
      |     r8--+   r11+---+
      +-------------+--+   |
            |   |   |      |
            +---+   +------+

The following case was not covered in the Appendix and these assumptions were made:

        r20-------+
        +         +
        +  r21--+ +
        +  |    | +
        +---------+

    r20 is Adjacent to r21 AND r20 does not contain r21
 */

//TODO tests cover adjacency on the top or bottom, add tests to test adjacency on left and right
public class RectangleTest {
    Rectangle r1 = Rectangle.builder().ul(Point.builder().x(0).y(10).build())
            .lr(Point.builder().x(10).y(0).build()).build();
    Rectangle r2 = Rectangle.builder().ul(Point.builder().x(3).y(6).build())
            .lr(Point.builder().x(6).y(3).build()).build();
    Rectangle r3 = Rectangle.builder().ul(Point.builder().x(9).y(6).build())
            .lr(Point.builder().x(12).y(3).build()).build();
    Rectangle r4 = Rectangle.builder().ul(Point.builder().x(15).y(10).build())
            .lr(Point.builder().x(20).y(5).build()).build();
    Rectangle r5 = Rectangle.builder().ul(Point.builder().x(0).y(20).build())
            .lr(Point.builder().x(10).y(10).build()).build();
    Rectangle r6 = Rectangle.builder().ul(Point.builder().x(3).y(15).build())
            .lr(Point.builder().x(6).y(10).build()).build();
    Rectangle r7 = Rectangle.builder().ul(Point.builder().x(9).y(15).build())
            .lr(Point.builder().x(12).y(10).build()).build();
    Rectangle r8 = Rectangle.builder().ul(Point.builder().x(3).y(3).build())
            .lr(Point.builder().x(9).y(-1).build()).build();
    Rectangle r9 = Rectangle.builder().ul(Point.builder().x(-1).y(6).build())
            .lr(Point.builder().x(6).y(3).build()).build();
    Rectangle r10 = Rectangle.builder().ul(Point.builder().x(3).y(15).build())
            .lr(Point.builder().x(6).y(6).build()).build();
    Rectangle r11 = Rectangle.builder().ul(Point.builder().x(9).y(3).build())
            .lr(Point.builder().x(12).y(-1).build()).build();
    Rectangle r20 = Rectangle.builder().ul(Point.builder().x(0).y(10).build())
            .lr(Point.builder().x(10).y(0).build()).build();
    Rectangle r21 = Rectangle.builder().ul(Point.builder().x(5).y(5).build())
            .lr(Point.builder().x(7).y(0).build()).build();

    @Test
    void r1ShouldContainR2() {
        Assertions.assertTrue(r1.contains(r2));
    }

    @Test
    void r2ShouldNotContainR1() {
        Assertions.assertFalse(r2.contains(r1));
    }

    @Test
    void r1ShouldNotContainR3() {
        Assertions.assertFalse(r1.contains(r3));
    }

    @Test
    void r1ShouldNotContainR4() {
        Assertions.assertFalse(r1.contains(r4));
    }

    @Test
    void r20ShouldNotContainR21() {
        Assertions.assertFalse(r20.contains(r21));
    }

    @Test
    void r20ShouldBeSubLineAdjacentToR21() {
        Assertions.assertEquals(Adjacency.SUBLINE, r20.getAdjacent(r21));
    }

    @Test
    void r1ShouldBeProperAdjacentToR5() {
        Assertions.assertEquals(Adjacency.PROPER, r1.getAdjacent(r5));
    }

    @Test
    void r1ShouldBeSubLineAdjacentToR6() {
        Assertions.assertEquals(Adjacency.SUBLINE, r1.getAdjacent(r6));
    }

    @Test
    void r1ShouldBePartialAdjacentToR7() {
        Assertions.assertEquals(Adjacency.PARTIAL, r1.getAdjacent(r7));
    }

    @Test
    void r1ShouldNotBeAdjacentToR4() {
        Assertions.assertEquals(Adjacency.NONE, r1.getAdjacent(r4));
    }

    @Test
    void r1ShouldIntersectR3() {
        List<Point> points = r1.getIntersectingPoints(r3);

        Assertions.assertEquals(2, points.size());
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getRight()).y(r3.getTop()).build()));
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getRight()).y(r3.getBottom()).build()));

    }

    @Test
    void r1ShouldIntersectR8() {
        List<Point> points = r1.getIntersectingPoints(r8);

        Assertions.assertEquals(2, points.size());
        Assertions.assertTrue(points.contains(Point.builder().x(r8.getRight()).y(r1.getBottom()).build()));
        Assertions.assertTrue(points.contains(Point.builder().x(r8.getLeft()).y(r1.getBottom()).build()));
    }

    @Test
    void r1ShouldIntersectR9() {
        List<Point> points = r1.getIntersectingPoints(r9);

        Assertions.assertEquals(2, points.size());
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getLeft()).y(r9.getBottom()).build()));
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getLeft()).y(r9.getTop()).build()));
    }

    @Test
    void r1ShouldIntersectR10() {
        List<Point> points = r1.getIntersectingPoints(r10);

        Assertions.assertEquals(2, points.size());
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getLeft()).y(r10.getTop()).build()));
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getRight()).y(r10.getTop()).build()));
    }

    @Test
    void r1ShouldIntersectR11() {
        List<Point> points = r1.getIntersectingPoints(r11);

        Assertions.assertEquals(2, points.size());
        Assertions.assertTrue(points.contains(Point.builder().x(r11.getLeft()).y(r1.getBottom()).build()));
        Assertions.assertTrue(points.contains(Point.builder().x(r1.getRight()).y(r11.getTop()).build()));
    }

    @Test
    void r1ShouldNotIntersectR4() {
        List<Point> points = r1.getIntersectingPoints(r4);

        Assertions.assertEquals(0, points.size());
    }
}

