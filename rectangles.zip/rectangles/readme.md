#Rectangles

Calculates the relationship between 2 rectangles.

**Containment**: Whether a rectangle is wholly contained within
another rectangle 

**Intersection**: Whether two rectangles have one or more
intersecting lines. A list of intersecting points are returned.

**Adjacency**: Detects whether two rectangles are adjacent. Adjacency is
defined as the sharing of at least one side. Side sharing may be proper, sub-line or partial. A
sub-line share is a share where one side of rectangle A is a line that exists as a set of points
wholly contained on some other side of rectangle B, where partial is one where some line
segment on a side of rectangle A exists as a set of points on some side of Rectangle B. 

### REST Interface
A limited REST interface is provided:

To retrieve a list of rectangles:
    <p><code>GET localhost:8080/rectangles</code>
    
To retrieve a specific rectangle with id '1':
    <p><code>GET localhost:8080/rectangles/1</code>

Add a rectangle to the service:
    <p><code>POST localhost:8080/rectangles</code><p>
sample payload: <code>{
"ul": {
"x": 0,
"y": 20
},
"lr": {
"x": 10,
"y": 10
}
}</code>


Calculate and return the relationship between 2 rectangles:
<p><code>GET localhost:8080/rectangles/relationship?id1=1&id2=2</code></p>


### Building
To build install maven and execute <code>mvn package</code> in the folder that contains the pom file.

### Running
<code>java -jar target\rectangles-0.0.1-SNAPSHOT.jar</code>